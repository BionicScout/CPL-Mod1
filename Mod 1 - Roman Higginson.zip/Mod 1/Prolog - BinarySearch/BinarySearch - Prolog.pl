% Binary search with output algorithm
binary_search(X, List, Result) :-
    %Do Binary Search Through Recursion 
    length(List, Length),
    binary_search(0, Length, X, List, Index),
    
    %Print Results
    write_result(Index, Result).

% Binary search algorithm
binary_search(LowerBound, UpperBound, X, List, Index) :-
    MidPoint is LowerBound + (UpperBound - LowerBound) // 2,
    
    nth0(MidPoint, List, Element),
    %Base Case: Found Element
    (Element = X ->
        Index = MidPoint
    
    %Base Case: Element Not Found
    ; UpperBound < LowerBound -> 
        Index = -1
    
    %If not found or outside of bounds, then reduce search window
    ; Element < X ->
        NewLowerBound is MidPoint + 1,
        binary_search(NewLowerBound, UpperBound, X, List, Index)
    ; Element > X ->
        NewUpperBound is MidPoint - 1,
        binary_search(LowerBound, NewUpperBound, X, List, Index)
    ).

% Write out the result
write_result(Index, Result) :-
    %Output if Result in List
    (Index = -1 ->
        format('Result is not in list~n', []),
        Result = -1
    
    %Output the Result that was found
    ; format('Index: ~w~n', [Index]),
      Result = Index
    ).