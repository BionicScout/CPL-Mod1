﻿using System;

class MyList {
    public List<int> list = new List<int> { 2 , 4 , 6 , 8 , 10 , 12 , 14 , 16 };

    public int BinarySearch(int target) {
        return BinarySearch(target , 0 , list.Count - 1);
    }

    public int BinarySearch(int target , int lowerBound , int upperBound) {
        int midPoint = lowerBound + ((upperBound - lowerBound) / 2);

        //Base Case: Target Found
        if(list[midPoint] == target)
            return midPoint;

        //Base Case: Not Found
        if(upperBound < lowerBound)
            return -1;

        //Adjust Bounds: Reduce Upperbound
        if(list[midPoint] > target)
            return BinarySearch(target , lowerBound , midPoint - 1);

        //Adjust Bounds: Increase LowerBound
        return BinarySearch(target , midPoint + 1 , upperBound);
    }

    static void Main() {
        //Adjustable feild
        int target = 16;

        //Search and Results
        MyList myList = new MyList();
        int result = myList.BinarySearch(target);

        if(result != -1)
            Console.WriteLine("Element found at index " + result);
        else
            Console.WriteLine("Element not found in the array");
    }
}