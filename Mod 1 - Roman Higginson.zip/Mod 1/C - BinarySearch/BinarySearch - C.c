#include <stdio.h>

int BinarySearch(int list[], int lowerBound, int upperBound, int target) {
    while(lowerBound <= upperBound){
        int midPoint = lowerBound + ((upperBound - lowerBound) / 2);

        //Base Case: Target Found
        if(list[midPoint] == target)
            return midPoint;

        //Adjust Bounds
        if(list[midPoint] > target)
            upperBound = midPoint - 1;
        else
            lowerBound = midPoint + 1;
    }
    
    //Base Case: Not Found
    return -1;
}

int main() {
    //Adjustable feild
    int list[] = { 2 , 4 , 6 , 8 , 10 , 12 , 14 , 16 };
    int target = 18;

    //Search
    int listSize = sizeof(list) / sizeof(list[0]); //Size of array in bytes / size of array element in bytes = size of array


    int result = BinarySearch(list, 0, listSize - 1, target);

    //Print Results
    if (result == -1)
        printf("Element %d is not present in the array\n", target);
    else
        printf("Element %d is present at index %d\n", target, result);

    return 0;
}