import Text.Printf (printf)

main :: IO()
main = do
-- Defining search results
   let myList = [1,3..21] -- Generates Odd Number List form 1 to 21 - [1, 3, 5, 7, 9, ..., 19, 21]
   let target = 2

   -- Print Basic Info and Search Results
   print ("Start of Function")
   print ("If Midpoint of Binary Search is equal to -1, then target number is not in list")
   print ("Target Number: " ++ intToString target)
   print ("Midpoint (Index in List): " ++ intToString (binarySearch 0 (length myList - 1) target myList))

-- Turn an Integer value into a string 
intToString :: Int -> String
intToString n = printf "%d" n

-- Binary Search
binarySearch :: Int -> Int -> Int -> [Int] -> Int
binarySearch lowerBound upperBound target list
   -- Base Case: Found, return index
   | list !! mid == target = mid
   -- Base Case: Not in List, return -1
   | lowerBound > upperBound = -1
   -- If not found or outside of bounds, then reduce search window
   | list !! mid > target = binarySearch lowerBound (mid - 1) target list
   | otherwise = binarySearch (mid + 1) upperBound target list
   where
     mid = lowerBound + (( upperBound - lowerBound ) `div` 2)